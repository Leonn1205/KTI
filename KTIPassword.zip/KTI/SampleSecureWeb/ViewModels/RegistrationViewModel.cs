using System;
using System.ComponentModel.DataAnnotations;

namespace SampleSecureWeb.ViewModels;

public class RegistrationViewModel
{
    [Required(ErrorMessage = "Username harus diisi")]
    public string Username { get; set; } = string.Empty;

    [Required(ErrorMessage = "Password harus diisi")]
    [StringLength(100, ErrorMessage = "Password harus minimal {2} karakter.", MinimumLength = 12)]
    [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{12,}$", 
        ErrorMessage = "Password harus mengandung minimal satu huruf besar, satu huruf kecil, dan satu angka, serta minimal 12 karakter.")]
    public string Password { get; set; } = string.Empty;

    [Required]
    [DataType(DataType.Password)]
    [Display(Name = "Confirm password")]
    [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
    public string? ConfirmPassword { get; set; }
}
