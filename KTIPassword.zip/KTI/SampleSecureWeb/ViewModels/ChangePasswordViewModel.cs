using System.ComponentModel.DataAnnotations;

namespace SampleSecureWeb.ViewModels
{
    public class ChangePasswordViewModel
    {
        [Required(ErrorMessage = "Password lama harus diisi")]
        [DataType(DataType.Password)]
        public required string OldPassword { get; set; }

        [Required(ErrorMessage = "Password baru harus diisi")]
        [StringLength(100, ErrorMessage = "Password harus minimal {2} karakter.", MinimumLength = 12)]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{12,}$", 
            ErrorMessage = "Password harus mengandung minimal satu huruf besar, satu huruf kecil, dan satu angka.")]
        [DataType(DataType.Password)]
        public required string NewPassword { get; set; }

        [DataType(DataType.Password)]
        [Compare("NewPassword", ErrorMessage = "Password baru dan konfirmasi password tidak cocok.")]
        public required string ConfirmPassword { get; set; }
    }
}

