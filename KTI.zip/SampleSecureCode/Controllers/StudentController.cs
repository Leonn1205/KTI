using System;
using Microsoft.AspNetCore.Mvc;
using SampleSecureCode.Data;
using SampleSecureCode.Models;

namespace SampleSecureCode.Controllers;

public class StudentController : Controller
{
    private readonly IStudent _studentData;
    public StudentController(IStudent studentData)
    {
        _studentData = studentData;
    }
    public IActionResult Index()
    {
        var students = _studentData.GetStudents();
        return View(students);
    }

    public IActionResult Create()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Create(Student student)
    {
        try
        {
            _studentData.AddStudent(student);
            return RedirectToAction("Index");
        }
        catch (System.Exception ex)
        {
            ViewBag.ErrorMessage = ex.Message;
        }
        return View(student);
    }

    public IActionResult Edit(string id)
    {
        var student = _studentData.GetStudent(id);
        return View(student);
    }
}
