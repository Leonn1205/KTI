using System;
using SampleSecureCode.Models;

namespace SampleSecureCode.Data;

public interface IStudent
{
    IEnumerable<Student> GetStudents();
    Student GetStudent(string Nim);
    Student AddStudent(Student student);
    Student UpdateStudent(Student student);
    Student DeleteStudent(string Nim);
}
