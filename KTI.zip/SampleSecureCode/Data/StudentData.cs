using System;
using SampleSecureCode.Models;

namespace SampleSecureCode.Data;

public class StudentData : IStudent
{
    private readonly ApplicationDbContext _db;
    public StudentData(ApplicationDbContext db)
    {
        _db = db;
    }
    Student IStudent.AddStudent(Student student)
    {
        try
        {
            _db.Students.Add(student);
            _db.SaveChanges();
            return student;
        }
        catch (System.Exception ex)
        {
            throw new Exception(ex.Message);
        }
        
    }

    Student IStudent.DeleteStudent(string Nim)
    {
        throw new NotImplementedException();
    }

    Student IStudent.GetStudent(string Nim)
    {
        throw new NotImplementedException();
    }

    IEnumerable<Student> IStudent.GetStudents()
    {
        var Students = _db.Students.OrderBy(s => s.FullName);
        return Students;
    }

    Student IStudent.UpdateStudent(Student student)
    {
        throw new NotImplementedException();
    }
}
